package org.processmining.ptrframework.algorithms.treereplay.PM4PYApproach;

import org.processmining.ptrframework.utils.Pair;

import java.util.HashMap;

public class ProcessTreeState extends HashMap<Pair<Integer, ReplayProcessTree>, ReplayProcessTree.OperatorState> {
}
